<div id="all" class="">
                <?php
                    require_once '../../dao/hang-hoa.php';
                    $hh_array = hang_hoa_select_by_loai(4);
                    foreach ($hh_array as $hh) {
                        $href = "$SITE_URL/hang-hoa/chi-tiet.php?ma_hh=$hh[ma_hh]";
                        echo "
                         <div id='main-top'>
                         <div class='ui'>
                         <div class='sale-flash new'></div>
                            <div class='thongbao'>
                        <div class='main-hover'>
                            <a> Chọn Sản Phẩm</a>
                        </div>
                        <a href='$href'>
                        <button class='min'><i class='fas fa-search'></i></button></a>
                        <a href='../shoppingcart/addsp.php?id=$hh[ma_hh]'>
                        <button class='max'><i class='fas fa-cart-plus'></i></button>
                        </a>
                    </div>
                    <div class='misthi'>
                    <img src='$CONTENT_URL/images/products/$hh[hinh]'>
                    </div>
                    <div class='xece' style='height: 163px;'>
                    <h5><a href='$href'>$hh[don_gia]</a></h5>
                                
                                <p><a href='$href'>$hh[ten_hh]</a></p>
                                <p><i class='fas fa-eye'></i> $hh[so_luot_xem] </p>
                                <span>
                            <i class='far fa-star'></i>
                            <i class='far fa-star'></i>
                            <i class='far fa-star'></i>
                            <i class='far fa-star'></i>
                            <i class='far fa-star'></i>
                        </span>
                                </div>
                            </div>
                            </div>
                        ";
                    }
                ?>
</div>
