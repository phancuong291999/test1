<!DOCTYPE html>
<html>
    <body>
        <div class="page-header">
          <h1 style="text-align: center;"><small>TÀI KHOẢN</small></h1>
        </div>
        
            <div class="container">
          <div class="row">
            <div class="col-md-3">
              <div class="special-deal leftbar" style="margin-top:0;">
                <h4 class="title">
                  Special 
                  <strong>
                    Deals
                  </strong>
                </h4>
                <div class="special-item">
                  <div class="product-image">
                    <a href="details.html">
                      <img src="<?=$CONTENT_URL?>/images/products/thum/products-01.png" alt="">
                    </a>
                  </div>
                  <div class="product-info">
                    <p>
                      <a href="details.html">
                        Licoln Corner Unit
                      </a>
                    </p>
                    <h5 class="price">
                      $300.00
                    </h5>
                  </div>
                </div>
                <div class="special-item">
                  <div class="product-image">
                    <a href="details.html">
                      <img src="<?=$CONTENT_URL?>/images/products/thum/products-02.png" alt="">
                    </a>
                  </div>
                  <div class="product-info">
                    <p>
                      <a href="details.html">
                        Licoln Corner Unit
                      </a>
                    </p>
                    <h5 class="price">
                      $300.00
                    </h5>
                  </div>
                </div>
                <div class="special-item">
                  <div class="product-image">
                    <a href="details.html">
                      <img src="<?=$CONTENT_URL?>/images/products/thum/products-03.png" alt="">
                    </a>
                  </div>
                  <div class="product-info">
                    <p>
                      <a href="details.html">
                        Licoln Corner Unit
                      </a>
                    </p>
                    <h5 class="price">
                      $300.00
                    </h5>
                  </div>
                </div>
              </div>
              <div class="product-tag leftbar">
                <h3 class="title">
                  Products 
                  <strong>
                    Tags
                  </strong>
                </h3>
                <ul>
                  <?php
                    
                    $loai_array = loai_select_all();
                    foreach ($loai_array as $loai) {
                        $href = "$SITE_URL/hang-hoa/liet-ke.php?ma_loai=$loai[ma_loai]";
                        echo "
                        <li>
                            <a href='$href'>$loai[ten_loai]</a>
                        </li>
                        ";
                    }
                ?>
                </ul>
              </div>
              <div class="get-newsletter leftbar">
                <h3 class="title">
                  Get 
                  <strong>
                    newsletter
                  </strong>
                </h3>
                <p>
                  Casio G Shock Digital Dial Black.
                </p>
                <form>
                  <input class="email" type="text" name="" placeholder="Your Email...">
                  <input class="submit" type="submit" value="Submit">
                </form>
              </div>
              <div class="fbl-box leftbar">
                <h3 class="title">
                  Facebook
                </h3>
                <span class="likebutton">
                  <a href="#">
                    <img src="<?=$CONTENT_URL?>/images/fblike.png" alt="">
                  </a>
                </span>
                <p>
                  12k people like Flat Shop.
                </p>
                <ul>
                  <li>
                    <a href="#">
                    </a>
                  </li>
                  <li>
                    <a href="#">
                    </a>
                  </li>
                  <li>
                    <a href="#">
                    </a>
                  </li>
                  <li>
                    <a href="#">
                    </a>
                  </li>
                  <li>
                    <a href="#">
                    </a>
                  </li>
                  <li>
                    <a href="#">
                    </a>
                  </li>
                  <li>
                    <a href="#">
                    </a>
                  </li>
                  <li>
                    <a href="#">
                    </a>
                  </li>
                </ul>
                <div class="fbplug">
                  <a href="#">
                    <span>
                      <img src="<?=$CONTENT_URL?>/images/fbicon.png" alt="">
                    </span>
                    Facebook social plugin
                  </a>
                </div>
              </div>
            </div>
            <div class="col-md-9">
              <div class="checkout-page">
                <ol class="checkout-steps">
                  <li class="steps active">
                    <a href="checkout.html" class="step-title">
                      <small><?= $_SESSION['user']['ho_ten']?></small>
                    </a>
                    <div class="step-description">
                      <div>
                    <img src='<?=$CONTENT_URL?>/images/users/<?=$_SESSION['user']['hinh']?>' style='width: 100px;height:100px;border-radius: 100%;border: 1px solid #333;display: block;margin: 0 auto'>
                    <br>
                    
                </div>
                <ul class="list-group">
                    <li class="list-group-item"><a href="<?=$SITE_URL?>/tai-khoan/dang-nhap.php?btn_logoff">Đăng xuất</a></li>
                    <li class="list-group-item"><a href="<?=$SITE_URL?>/tai-khoan/doi-mk.php">Đổi mật khẩu</a></li>
                    <li class="list-group-item"><a href="<?=$SITE_URL?>/tai-khoan/cap-nhat-tk.php">Cập nhật tài khoản</a></li>
                    <?php
                    if($_SESSION['user']['vai_tro'] == false){
                        echo "<li class='list-group-item'><a href='../hang-hoa'>Thêm Mặt Hàng</a></li>";
                         echo "<li class='list-group-item'><a href='$SITE_URL/hang-hoa/binh-luan/binh-luan/'>Bình Luận</a></li>";
                         echo" <li class='list-group-item'><a href='$SITE_URL/don-hang/'>Đơn Hàng Bán</a></li>";
                         echo" <li class='list-group-item'><a href='$SITE_URL/don-hang/donhangmua.php'>Đơn Hàng Đang Mua Mua</a></li>";
                    }
                ?>
                <?php
                    if($_SESSION['user']['vai_tro'] == TRUE){
                        echo "<li class='list-group-item'><a href='$ADMIN_URL/trang-chinh'>Quản trị website</a></li>";
                    }
                ?>
                </ul>
                
                    </div>
                  </li>

                  </div>
                  <div class="checkout-page">
                    
                    <?php require '../layout/loai-hang-makh.php';?>
                  </div>

          </div>
        </div>     
    </body>
</html>
