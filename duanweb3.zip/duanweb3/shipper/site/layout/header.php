
    <div class="header">
            <div class="container">
               <div class="row">
                  <div class="col-md-2 col-sm-2">
                     <div class="logo"><a href="<?=$SITE_URL?>/trang-chinh?trangchu"><img src="<?=$CONTENT_URL?>/images/logo.png" alt="FlatShop"></a></div>
                  </div>
                  <div class="col-md-10 col-sm-10">
                     <div class="header_top">
                        <div class="row">
                           <div class="col-md-3">
                              <ul class="option_nav">
                                 <li class="dorpdown">
                                    <a href="#">Eng</a>
                                    <ul class="subnav">
                                       <li><a href="#">Eng</a></li>
                                       <li><a href="#">Vns</a></li>
                                       <li><a href="#">Fer</a></li>
                                       <li><a href="#">Gem</a></li>
                                    </ul>
                                 </li>
                                 <li class="dorpdown">
                                    <a href="#">USD</a>
                                    <ul class="subnav">
                                       <li><a href="#">USD</a></li>
                                       <li><a href="#">UKD</a></li>
                                       <li><a href="#">FER</a></li>
                                    </ul>
                                 </li>
                              </ul>
                           </div>
                           <div class="col-md-6">
                              <ul class="topmenu">
                                 <?php require 'menu.php'?>
                              </ul>
                           </div>
                           <div class="col-md-3">
                              <ul class="usermenu">
                                 <li ><?php if (isset($_SESSION['user'])):?>
                            
                           <a class="log" href="<?=$SITE_URL?>/trang-chinh?nguoi-dung"><?= $_SESSION['user']['ho_ten']?></a>
                           <li><a href="<?=$SITE_URL?>/tai-khoan/dang-nhap.php?btn_logoff" class="reg">Đăng Xuất</a></li>
                           <?php else:?>
                            <a href="<?=$SITE_URL?>//tai-khoan/dang-nhap.php" class="log">Đăng Nhập</a>
                        <?php endif ?></li>
                        <?php if (isset($_SESSION['user'])):?>
                          
                          <?php else:?>
                                 <li><a href="<?=$SITE_URL?>//tai-khoan/dang-ky.php" class="reg">Đăng Ký</a></li>
                                 <?php endif ?>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix"></div>
                     <div class="header_bottom">
                        <ul class="option">
                           <li id="search" class="search">
                              <form action="<?=$SITE_URL?>/hang-hoa/liet-ke.php" method="post" class="input-group search-bar" role="search" style='width: 123px'>
                              <input type="search" name="search" id="input" class="form-control" placeholder="Tìm Kiếm ..." required="required" title="" style="background: #ccc; border-radius: 5px;">
                           </form>
                           </li>
                           <!-- <li id="search" class="search">
                              <form action="<?=$SITE_URL?>/hang-hoa/liet-ke.php" method="post" class="input-group search-bar" role="search"><input class="search-submit" type="submit" value=""><input class="search-input" placeholder="Enter your search term..." type="text" value="" name="search"></form>
                           </li> -->
                           <li class="option-cart">
                              <a href="<?=$SITE_URL?>/shoppingcart/" class="cart-icon">cart <span class="cart_no">
                                <?php 
        
                  if (!isset($_SESSION["cart"])) {
                      echo 0;
                  }else {
                      echo count($_SESSION["cart"]);
                  }              
           ?>
                              </span></a>
                              <ul class="option-cart-item">
                                     <?php 
    if (isset($_SESSION['cart'])) :?>

      <tbody id="tbody">

        <?php foreach ($_SESSION['cart'] as $key => $value):?>

          <li> 
           <td data-th="Product"> 
            <div class="cart-item"> 
              <div class="image"><img style="max-width: 100px" src="../../content/images/products/<?=$value['hinh']?>" alt=""class="img-responsive">
             </div> 
             <div class="item-description"> 
              <p class="name"><?=$value['name']?></p> 
            </div> 
          </div> 

        </td> 
        <div class="right">
                                          <p class="price"><?=number_format($value['price'],0,'.','.')?></p>
                                          <a href="delete.php?id=<?php echo $value['ma_hh'] ?>" class="remove"><img src="<?=$CONTENT_URL?>/images/remove.png" alt="remove"></a>
                                       </div> 
      </li> 
      <tr> 



        <?php 
        
      endforeach; ?>
      <?php else: ?>
      <p >Giỏ Hàng Trống</p>
     <?php endif; 

     ?>
                                 <li><span class="total">Total <strong>$60.00</strong></span><button class="checkout" onClick="location.href='checkout.html'">CheckOut</button></li>
                              </ul>
                           </li>
                        </ul>
                        <div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button></div>
                        <div class="navbar-collapse collapse">
                           <ul class="nav navbar-nav">
                              <li class="active dropdown">
                                 <a href="<?=$SITE_URL?>/trang-chinh?trangchu"" class="dropdown-toggle" data-toggle="dropdown">Home</a>
                                 <div class="dropdown-menu">
                                    <ul class="mega-menu-links">
                                       <li><a href="index.html">home</a></li>
                                       <li><a href="home2.html">home2</a></li>
                                       <li><a href="home3.html">home3</a></li>
                                       <li><a href="productlitst.html">Productlitst</a></li>
                                       <li><a href="productgird.html">Productgird</a></li>
                                       <li><a href="details.html">Details</a></li>
                                       <li><a href="cart.html">Cart</a></li>
                                       <li><a href="checkout.html">CheckOut</a></li>
                                       <li><a href="checkout2.html">CheckOut2</a></li>
                                       <li><a href="contact.html">contact</a></li>
                                    </ul>
                                 </div>
                              </li>
                             <?php
                    require '../../dao/loai.php';
                    $loai_array = loai_select_all();
                    foreach ($loai_array as $loai) {
                        $href = "$SITE_URL/hang-hoa/liet-ke.php?ma_loai=$loai[ma_loai]";
                        echo "
                        <li>
                            <a href='$href'>$loai[ten_loai]</a>
                        </li>
                        ";
                    }
                ?>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         