<li><a href="<?=$SITE_URL?>/trang-chinh?gioi_thieu">GIỚI THIỆU</a></li>
        <li><a href="<?=$SITE_URL?>/trang-chinh?lien_he">LIÊN HỆ</a></li>
        <li><a href="<?=$SITE_URL?>/trang-chinh?gop_y">GÓP Ý</a></li>
        <li><a href="<?=$SITE_URL?>/trang-chinh?hoi_dap">HỎI ĐÁP</a></li>
