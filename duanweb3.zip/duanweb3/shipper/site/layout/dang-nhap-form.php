
             <div id="main-content">
            <h2>ĐĂNG NHẬP</h2>
        </div>
            <div class="form-nhap">
                <form action="<?=$SITE_URL?>/tai-khoan/dang-nhap.php" method="post">
                    <div class="form-group">
                        <label for="">Tên Đăng Nhập</label><span class="req">*</span>
                        <input name="ma_kh" class="form-control"  value="<?=$ma_kh?>">
                    </div>
                    <div class="form-group">
                       <label for="">Mật Khẩu</label><span class="req">*</span>
                        <input type="text" name="mat_khau" class="form-control" id="" placeholder="Input field">
                    </div>
                    <div>
                        <div>
                            <label>
                                <input name="ghi_nho" type="checkbox" checked>
                                Ghi nhớ tài khoản?
                            </label>
                        </div>
                    </div>
                    <div>
                        <button name="btn_login" class="button">Đăng nhập</button>
                    </div>
                    <div>
                        <li><a style="color:#333" href="<?=$SITE_URL?>/tai-khoan/quen-mk.php">Quên mật khẩu</a></li>
                        <li><a style="color:#333" href="<?=$SITE_URL?>/tai-khoan/dang-ky.php">Đăng ký thành viên</a></li>
                    </div>
                    
                </form>    
            </div>       