
                <?php
                require '../../dao/hang-hoa.php';                    require '../../dao/loai.php';
                    $loai_array = loai_select_all();
                    echo "<pre>";

                    foreach ($loai_array as $loai) {
                       // $href = "$SITE_URL/hang-hoa/liet-ke.php?ma_loai=$loai[ma_loai]";
                       //  echo "<div id='main-content'><a href='$href'>$loai[ten_loai]</a></div>";            
        			echo $loai['ten_loai']."<br><br><br><br><br><br>";
        			$a=hang_hoa_select_by_loai($loai['ma_loai']);
        			//print_r($a);
        			  foreach ($a as $key => $value) {
                     echo $value['ten_hh']."<br>";	
                   }
               }
                   // foreach ($a as $key => $value) {
                    //	print_r($value);
                    
                ?>