<div class="hot-products">
    <h3 class="title"><strong>Top</strong> 4</h3>
    <div class="control"><a id="prev_hot" class="prev" href="#" style="display: block;">&lt;</a><a id="next_hot" class="next" href="#" style="display: block;">&gt;</a></div>
    <div class="caroufredsel_wrapper" style="display: block; text-align: start; float: left; position: relative; top: auto; right: auto; bottom: auto; left: auto; z-index: auto; width: 1140px;height: 500px; margin: 0px; overflow: hidden;"><ul id="hot" style="text-align: left; float: none; position: absolute; top: 0px; right: auto; bottom: auto; left: 0px; margin: 0px; width: 5700px; height: 418px; z-index: auto;"><li style='width: 1140px;'>
                          <div class='row'>
                <?php
                    require_once '../../dao/hang-hoa.php';
                    $hh_array = hang_hoa_select_top10();
                    foreach ($hh_array as $hh) {

                        $href = "$SITE_URL/hang-hoa/chi-tiet.php?ma_hh=$hh[ma_hh]";
                        echo "
                         <div class='col-md-3 col-sm-6'>
                         <div class='products'>
                         <div class='offer'><a href='$href'> See details</a> </div>
                         <div class='thumbnail'><img src='$CONTENT_URL/images/products/$hh[hinh]' alt='Product Name'></div>
                         <div class='productname'>$hh[ten_hh]</div>
                         <h4 class='price'>$hh[don_gia]</h4>
                         <div class='button_group'><a href='../shoppingcart/addsp.php?id=$hh[ma_hh]'><button class='button add-cart' type='button'>Add To Cart</button></a><a><button class='button compare' type='button'><i class='fa fa-exchange'></i></button></a><button class='button wishlist' type='button'> $hh[so_luot_xem]</button></div>
                        
                        </div>
                        </div>
                        ";
                    }
                ?>
                </div>
                                </li>
</ul>
</div>
</div>
