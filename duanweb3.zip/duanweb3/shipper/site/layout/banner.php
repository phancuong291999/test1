        <div id="banner">
            <figure id="main-banner">
                <a>
                    <img class="img-responsive" src="<?=$CONTENT_URL?>/images/banner_1.png" alt="Banner 1">
                </a>
                <div id="th">
                </div>
            </figure>
            <figure id="main1-banner">
                <a>
                    <img class="img-responsive" src="<?=$CONTENT_URL?>/images/banner_2.png" alt="Banner 1">
                </a>
            </figure>
        </div>