<h3 class="alert alert-success" style="text-align: center;">MẶT HÀNG CỦA BẠN</h3>
                                        <table style="    border: 1px solid #cccccc" class='table table-striped'>
                        <thead>
                        <tr>
                            <th>Tên Sản Phẩm</th>
                            <th>Giới Thiệu Sản Phẩm</th>
                            <th>Giá Tiền</th>
                            <th>Hình Ảnh</th>
                            <th>Khác </th>
                    </thead>
                    <tbody>
                <?php
                $ma_kh = get_cookie("ma_kh");
                    require '../../dao/hang-hoa.php';
                    $loai_array = hang_hoa_select_by_kh($ma_kh);
                    foreach ($loai_array as $loai) {
                        $href = "$SITE_URL/hang-hoa/liet-ke.php?ma_loai=$loai[ma_loai]";

                        echo "
                    
                        <tr>
                            <td><a href='$href'>$loai[ten_hh]</a></td>
                            <td>$loai[mo_ta]</td>
                            <td>$loai[don_gia]</td>
                            <td><img src='../../content/images/products/$loai[hinh]' style='border-radius:100%;max-width:40%;max-height:90%;'></td>
                            <td><a href='$SITE_URL/layout/delete.php?btn_delete&ma_hh=$loai[ma_hh]'><button type='button' class='btn btn-sm btn-default'>Xóa</button></a> <a href='$SITE_URL/hang-hoa/edit.php?btn_edit&ma_hh=$loai[ma_hh]'>  <button type='button' class='btn btn-sm btn-default'>Edit</button></a></td>
                        </tr>
                       
                        
                        ";
                    }

                ?>
                 </tbody>
                </table>