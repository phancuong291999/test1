<!DOCTYPE html>
<html>
    <body>
        <div style="width: 80%;margin: 0 auto;">
        <h3 class="alert alert-success">TỔNG HỢP BÌNH LUẬN</h3>
        <form action="index.php" method="post">
            <table class="table table-hover" style="    border: 1px solid #cccccc">
                <thead>
                    <tr>
                        <th>HÀNG HÓA</th>
                        <th>SỐ BL</th>
                        <th>MỚI NHẤT</th>
                        <th>CŨ NHẤT</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    foreach ($items as $item){
                        extract($item);
                ?>
                    <tr>
                        <td><?=$ten_hh?></td>
                        <td><?=$so_luong?></td>
                        <td><?=$cu_nhat?></td>
                        <td><?=$moi_nhat?></td>
                        <td>
                            <a href="../binh-luan/index.php?ma_hh=<?=$ma_hh?>">Chi tiết</a>
                        </td>
                    </tr>
                <?php
                    }
                ?>
                </tbody>
            </table>
            <a href="<?=$SITE_URL?>/trang-chinh?nguoi-dung" class="btn btn-default">Quay Về</a>
        </form>
    </div>
    </body>
</html>
