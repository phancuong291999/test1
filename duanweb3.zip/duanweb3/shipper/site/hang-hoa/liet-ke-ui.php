<!DOCTYPE html>
<html><head>
    <style type="text/css">
       .thumbnail{
        display: block;
    padding: 4px;
    margin-bottom: 20px;
    line-height: 1.42857143;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    -webkit-transition: border .2s ease-in-out;
    -o-transition: border .2s ease-in-out;
    transition: border .2s ease-in-out;
       }
    </style>
</head>
    <body>

        <div class="container_fullwidth">
        <div class="container">
            <?php   
            include_once '../../dao/loai.php';
            $haha=loai_select_by_id($_GET['ma_loai']);
           echo '<h2>'.$haha['ten_loai'].'</h2>';
             ?>
                <div class="row">
        <?php

            foreach ($items as $item) {

                extract($item);
        ?>
            <div class="col-md-3 col-sm-6">
                <div class="products">
                    <div class="offer"><a href="<?=$SITE_URL?>/hang-hoa/chi-tiet.php?ma_hh=<?=$ma_hh?>"><i class="fas fa-eye"></i> See Details</a> </div>
                    <div class="thumbnail"><img src="<?=$CONTENT_URL?>/images/products/<?=$hinh?>"> </div>
                    <div class='productname'><?=$ten_hh?></div>
                    <h4 class='price'>$<?=number_format($don_gia, 2)?></h4>
                     <div class='button_group'><a href='<?=$SITE_URL?>/shoppingcart/addsp.php?id=<?=$ma_hh?>'><button class='button add-cart' type='button'>Add To Cart</button></a><a><button class='button compare' type='button'><i class='fa fa-exchange'></i></button></a><button class='button wishlist' type='button'><?=$so_luot_xem?></button></div>
                    
                </div>
            </div>
        <?php
            }
        ?>
        </div>
        </div>
    </div>
    </body>
</html>