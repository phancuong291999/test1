<?php
require "../../global.php";
require "../../dao/hang-hoa.php";
//--------------------------------//
require "../../dao/loai.php";

check_login();

extract($_REQUEST);
if(exist_param("btn_edit")){
    $item = hang_hoa_select_by_id($ma_hh);
    extract($item);
    $VIEW_NAME = "hang-hoa/edit.php";
}
else if(exist_param("btn_update")){
    $up_hinh = save_file("up_hinh", "$IMAGE_DIR/products/");
    $hinh = strlen($up_hinh) > 0 ? $up_hinh : $hinh;
    try {
        hang_hoa_update($ma_hh, $ten_hh, $don_gia, $giam_gia, $hinh, $ma_loai, $dac_biet, $so_luot_xem, $ngay_nhap, $mo_ta);
        $MESSAGE = "Cập nhật thành công!";
    } 
    catch (Exception $exc) {
        echo $exc->getMessage();
        $MESSAGE = "Cập nhật thất bại!";
    }
    $VIEW_NAME = "edit.php";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <!-- Latest compiled and minified CSS & JS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <script src="//code.jquery.com/jquery.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
</head>
    <body>
        <div style="width: 80%;margin: 0 auto;">
        <h3 class="alert alert-success">QUẢN LÝ HÀNG HÓA</h3>
        <?php
            if(strlen($MESSAGE)){
                echo "<h5>$MESSAGE</h5>";
            }
        ?>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="form-group col-sm-4">
                    <label>MÃ HÀNG HÓA</label>
                    <input class="form-control" name="ma_hh" readonly value="<?=$ma_hh?>">
                </div>
                <div class="form-group col-sm-4">
                    <label>TÊN HÀNG HÓA</label>
                    <input class="form-control" name="ten_hh" value="<?=$ten_hh?>">
                </div>
                <div class="form-group col-sm-4">
                    <label>ĐƠN GIÁ</label>
                    <input class="form-control" name="don_gia" value="<?=$don_gia?>">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-sm-4">
                    <label>GIẢM GIÁ</label>
                    <input name="giam_gia" value="<?=$giam_gia?>">
                </div>
                <div class="form-group col-sm-4">
                    <label>HÌNH ẢNH</label>
                    <input name="up_hinh" type="file">
                    <input name="hinh" type="hidden" value="<?=$hinh?>"> (<?=$hinh?>)
                </div>
                <div class="form-group col-sm-4">
                    <label>LOẠI HÀNG</label>
                    <select name="ma_loai">
                        <?php
                            foreach ($loai_select_list as $loai) {
                                if($loai['ma_loai'] == $ma_loai){
                                    echo '<option selected value="'.$loai['ma_loai'].'">'.$loai['ten_loai'].'</option>';
                                }
                                else{
                                    echo '<option value="'.$loai['ma_loai'].'">'.$loai['ten_loai'].'</option>';
                                }
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-sm-4">
                    <label>HÀNG ĐẶC BIỆT?</label>
                    <div>
                        <label><input name="dac_biet" value="0" type="radio" <?=$dac_biet?'':'checked'?>>Đặc biệt</label>
                        <label><input name="dac_biet" value="1" type="radio"<?=$dac_biet?'checked':''?>>Bình thường</label>
                    </div>
                </div>
                <div class="form-group col-sm-4">
                    <label>NGÀY NHẬP</label>
                    <input name="ngay_nhap" value="<?=$ngay_nhap?>">
                </div>
                <div class="form-group col-sm-4">
                    <label>SỐ LƯỢC XEM</label>
                    <input name="so_luot_xem" readonly value="0" value="<?=$so_luot_xem?>">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-sm-12">
                    <label>MÔ TẢ</label>
                    <textarea name="mo_ta" rows="4" class="form-control"><?=$mo_ta?></textarea>
                </div>
                <div>
                    <button class="btn btn-default" name="btn_update">Cập nhật</button>
                    <button class="btn btn-default" type="reset">Nhập lại</button>
                    <a href="index.php">Thêm mới</a>
                    <a href="index.php?btn_list">Danh sách</a>
                </div>
            </div>
        </form>
    </div>
    </body>
</html>
