<div class="container_fullwidth" >
    <div class="container">
     <?php require '../layout/top10.php' ?>
     <div class="hot-products">
      <h3 class="title"><strong>SẢN PHẨM</strong>(Tất Cả)</h3>
      <div class="caroufredsel_wrapper" style="display: block; text-align: start; float: left; position: relative; top: auto; right: auto; bottom: auto; left: auto; z-index: auto; width: 1140px;height: 5500px; margin: 0px; overflow: hidden;"><ul id="hot" style="text-align: left; float: none; position: absolute; top: 0px; right: auto; bottom: auto; left: 0px; margin: 0px; width: 5700px; height: 418px; z-index: auto;"><li style='width: 1140px;'>
                          <div class='row'>
                <?php
                    require_once '../../dao/hang-hoa.php';
                    $hh_array = hang_hoa_select_all();
                    foreach ($hh_array as $hh) {

                        $href = "$SITE_URL/hang-hoa/chi-tiet.php?ma_hh=$hh[ma_hh]";
                        echo "
                         <div class='col-md-3 col-sm-6'>
                         <div class='products'>
                         <div class='offer'><a href='$href'> See details</a> </div>
                         <div class='thumbnail'><a href='$href'><img src='$CONTENT_URL/images/products/$hh[hinh]' alt='Product Name'></a></div>
                         <div class='productname'>$hh[ten_hh]</div>
                         <h4 class='price'>$hh[don_gia]</h4>
                         <div class='button_group'><a href='../shoppingcart/addsp.php?id=$hh[ma_hh]'><button class='button add-cart' type='button'>Add To Cart</button></a><a><button class='button compare' type='button'><i class='fa fa-exchange'></i></button></a><button class='button wishlist' type='button'> $hh[so_luot_xem]</button></div>
                        
                        </div>
                        </div>
                        ";
                    }
                ?>
                </div>
                                </li>
</ul>
</div>
             </div>
</div>
</div>
<div class="our-brand">
                  <h3 class="title"><strong>Our </strong> Brands</h3>
                  <div class="control"><a id="prev_brand" class="prev" href="#" style="display: block;">&lt;</a><a id="next_brand" class="next" href="#" style="display: block;">&gt;</a></div>
                  <div class="caroufredsel_wrapper" style="display: block; text-align: start; float: left; position: relative; top: auto; right: auto; bottom: auto; left: auto; z-index: auto; width: 1140px; height: 97px; margin: 0px; overflow: hidden;"><ul id="braldLogo" style="text-align: left; float: none; position: absolute; top: 0px; right: auto; bottom: auto; left: 0px; margin: 0px; width: 5700px; height: 97px;">
                     <li style="width: 1140px;">
                        <ul class="brand_item">
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/envato.png" alt=""></div>
                              </a>
                           </li>
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/themeforest.png" alt=""></div>
                              </a>
                           </li>
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/photodune.png" alt=""></div>
                              </a>
                           </li>
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/activeden.png" alt=""></div>
                              </a>
                           </li>
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/envato.png" alt=""></div>
                              </a>
                           </li>
                        </ul>
                     </li>
                     <li style="width: 1140px;">
                        <ul class="brand_item">
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/envato.png" alt=""></div>
                              </a>
                           </li>
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/themeforest.png" alt=""></div>
                              </a>
                           </li>
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/photodune.png" alt=""></div>
                              </a>
                           </li>
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/activeden.png" alt=""></div>
                              </a>
                           </li>
                           <li>
                              <a href="#">
                                 <div class="brand-logo"><img src="images/envato.png" alt=""></div>
                              </a>
                           </li>
                        </ul>
                     </li>
                  </ul></div>
               </div>