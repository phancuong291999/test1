         <div id="all">
            <?php
            foreach ($items as $item) {
                extract($item);
        ?>
            <div id="main-top">
                <div class="ui">
                    <div class="sale-flash new"><img src="<?=$CONTENT_URL?>/images/giphy.gif" style="width: 150%; height: 150%;"/></div>
                    <div class="thongbao">
                        <div class="main-hover">
                            <a> Chọn Sản Phẩm</a>
                        </div>
                        <a href="../hang-hoa/chi-tiet.php?ma_hh=<?=$ma_hh?>">
                       <button class="min"><i class="fas fa-search"></i></button></a>
                        <button class="max"><i class="far fa-heart"></i></button>
                    </div>
                <div class="misthi">
                    <a href="chi-tiet.php?ma_hh=<?=$ma_hh?>">
                        <img src="<?=$CONTENT_URL?>/images/products/<?=$hinh?>">
                    </a>
                    </div>
                        <div class="xece">
                        <h5><a>$<?=number_format($don_gia, 2)?></a></h5>
                        <p><a href="../hang-hoa/chi-tiet.php?ma_hh=<?=$ma_hh?>"><?=$ten_hh?></a></p>
                        <span>
                            <i class="far fa-star"></i>
                            <i class="far fa-star"></i>
                            <i class="far fa-star"></i>
                            <i class="far fa-star"></i>
                            <i class="far fa-star"></i>
                        </span>
                    </div>
                </div>
            </div>
        <?php
            }
        ?>
    </div>
