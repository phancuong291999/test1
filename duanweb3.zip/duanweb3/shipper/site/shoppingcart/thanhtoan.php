<?php 
require_once '../../global.php';
  // $user= pdo_query_one('ma_kh',intval($_SESSION['user']));
// echo  '<pre/>';
// var_dump($_SESSION['cart'])
$db=new Db();
extract($_SESSION['user']);
if(exist_param("xacnhan")) {
  session_destroy();
  $data=[
    'gia_dh'=>$_SESSION['tongtien'],
    'note'=> $_POST['note'],
    'dia_chi'=>$_POST['dia_chi'],
    'ma_kh'=> $ma_kh,
    'trang_thai'=> 'Chưa Xác Nhận',
    'ma_kh_ban'=>$_SESSION['ma_kh_ban']

  ];
  $idtran=$db->insert("thanh_toan",$data);
  if($idtran>0){
    foreach ($_SESSION['cart'] as $key => $value) {
      $data2=[
       'ma_TT'=>$idtran,
        'ma_hh'=>$key,
        'so_luong'=>$value['qty'],
        'gia_SP'=>$value['price'],
        'ten_SP'=>$value['name'],
        
      ];
      $idinsert=$db->insert("don_hang",$data2);
      $_SESSION["success"]="Đơn hàng đang được xử lý !!! </br> Đơn hàng sẽ được chuyển đến bạn trong thời gian ngắn nhất có thể !!! </br>";
    
      // // chuyen huong
      echo "<script type='text/javascript'>
      alert('Cảm Ơn Bạn Đã Đặt Hàng . Đơn Hàng Sẽ Được Xử Lý Sớm Nhất');
          window.location.href = '../trang-chinh/';
        </script>
       ";
    }
  }
}
?>

<!DOCTYPE html>
<html>
<head>
	<head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="shortcut icon" href="<?=$CONTENT_URL?>/images/favicon.png">
      <title>Welcome to FlatShop</title>
      <link href="<?=$CONTENT_URL?>/css/bootstrap.css" rel="stylesheet">
      <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,700,500italic,100italic,100' rel='stylesheet' type='text/css'>
      <link href="<?=$CONTENT_URL?>/css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="<?=$CONTENT_URL?>/css/flexslider.css" type="text/css" media="screen"/>
      <link href="<?=$CONTENT_URL?>/css/sequence-looptheme.css" rel="stylesheet" media="all"/>
      <link href="<?=$CONTENT_URL?>/css/style.css" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/v4-shims.css">
      <script>
        $(function (){
            $(".datepicker").datepicker({dateFormat:'yy-mm-dd'});
        });
        </script>
        <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery-1.10.2.min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.easing.1.3.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.sequence-min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.carouFredSel-6.2.1-packed.js"></script>
      <script defer src="<?=$SITE_URL?>/js/jquery.flexslider.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/script.min.js" ></script>
      <style>
        .thumbnail img {
          max-height: 100%;
        }
      </style>
</head>
<body>
  <div style="width: 80%;margin: 0 auto;">
    <h3 class="alert alert-success">Thanh toán</h3>
  <form method="POST" role="form" action="thanhtoandex.php">
                <div class="form-group">
                    <div class="form-group">
                        <label>Mã Khách Hàng</label>
                        <input class="form-control" readonly="" name="ma_kh" value="<?=$ma_kh?>" readonly>
                    </div>
                    <div class="form-group">
                        <label>Họ và tên</label>
                        <input  class="form-control" readonly="" name="ho_ten" value="<?=$ho_ten?>">
                    </div>
                    <div class="form-group">
                        <label>Địa chỉ email</label>
                        <input class="form-control" readonly="" name="email" value="<?=$email?>">
                    </div>
                    <div class="form-group">
                        <label>Địa chỉ giao hàng</label>
                        <input class="form-control"  name="dia_chi" value="">
                    </div>
                    <div class="form-group">
                      <label>Ghi chú</label>
                      <textarea class="form-control" placeholder="Tới nơi thì gọi " name="note" id="note" rows="3"></textarea>
                    </div>
                </div>
                <button class="btn btn-default" type="submit"  name="xacnhan"> Xác nhận</button>
        </form>
      </div>
</body>
</html>