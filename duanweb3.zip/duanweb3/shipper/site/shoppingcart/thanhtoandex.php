<?php
require '../../global.php';
require '../../dao/hang-hoa.php';
//-------------------------------//
require 'thanhtoan.php';