

<!DOCTYPE html>
<html>
<body>
  
  <?php
  require '../layout/header.php';
  $tongtien=0;
  ?>
  <div id="content">
  <div class="container" style="clear: both; padding-top: 2%;"> 
    <form action="" method="POST">
     <table border="1px" id="cart" class="table table-hover table-condensed"> 
      <thead> 
       <tr> 
        <th style="width:50%">Tên sản phẩm</th> 
        <th style="width:10%">Giá</th> 
        <th style="width:8%">Số lượng</th> 
        <th style="width:22%" class="text-center">Thành tiền</th> 
        <th style="width:10%"> </th> 
      </tr> 
    </thead> 
    <?php 
    if (isset($_SESSION['cart'])) :?>

      <tbody id="tbody">

        <?php foreach ($_SESSION['cart'] as $key => $value):?>

          <tr> 
           <td data-th="Product"> 
            <div class="row"> 
             <div class="col-sm-2 hidden-xs"><img style="max-width: 100px" src="../../content/images/products/<?=$value['hinh']?>" alt=""class="img-responsive">
             </div> 
             <div class="col-sm-10"> 
              <h4 class="nomargin"><?=$value['name']?></h4> 
              <p style="font-size: 13px;font-weight: bold"><?=$value['mo_ta']?></p> 
            </div> 
          </div> 
        </td> 
        <td data-th="Price"><?=number_format($value['price'],0,'.','.')?> đ</td> 
        <td data-th="Quantity"><input class="form-control text-center" 
          value="<?php echo $value['qty'] ?>" 
          id="qty" name="qty[<?php echo $value['ma_hh']; ?>]"  type="number" >
        
        </td> 
        <td data-th="Subtotal" class="text-center"><?=number_format($value['price']*$value['qty'],0,'.','.')?> đ</td> 
        <td class="actions" data-th="">

          <a href="delete.php?id=<?php echo $value['ma_hh'] ?>" style="margin-left:46%;"><i class="fas fa-trash"></i>
          </a>
        </td> 
      </tr> 
      <tr> 



        <?php 
        $tongtien+=$_SESSION['cart'][$key]['price']*$_SESSION['cart'][$key]['qty'];
        $_SESSION['tongtien']= $tongtien;
      endforeach; ?>
      <?php else: ?>
      <h1 style="color:red;text-align: center;">GIỎ HÀNG TRỐNG</h1>
     <?php endif; 
     ?>
   </tbody>
   <tfoot>  
     <tr> 
      <td><a href="../trang-chinh/index.php" class="btn btn-warning"><i class="fa fa-angle-left"></i> Tiếp tục mua hàng</a>

       <input type="submit" class="btn btn-warning updatecart"  name="submit" value="Làm mới giỏ hàng" id="muahang" data-key="<?php echo $key ?>">
     </form>
     

   </td> 
   <td colspan="2" class="hidden-xs"> </td> 
   <td class="hidden-xs text-center"><strong><?php   echo number_format($tongtien,0,'.','.')?>đ</strong>
   </td>

   <td>
    <?php if (isset($_SESSION['user'])):?>
    <a href="thanhtoandex.php" class="btn btn-success btn-block"> <?php 
        
                  if (!isset($_SESSION["cart"])) {
                      echo '';
                  }else {
                      echo 'Thanh Toán';
                  }              
           ?> <i class="fa fa-angle-right"></i></a>
     <?php else:?>
    <a href="<?=$SITE_URL?>//tai-khoan/dang-nhap.php" class="btn btn-success btn-block">Đăng nhập</a>
    <?php endif ?>
   </td> 
 </tr> 
</tfoot> 
</table>
</div>




</div>
</div>
<?php require '../layout/footer.php';?> 
</body>
</html>
