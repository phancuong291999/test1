<?php 

require '../../global.php';


?> 
<!DOCTYPE html>
<html>
<head>
	<head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="shortcut icon" href="<?=$CONTENT_URL?>/images/favicon.png">
      <title>Welcome to FlatShop</title>
      <link href="<?=$CONTENT_URL?>/css/bootstrap.css" rel="stylesheet">
      <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,700,500italic,100italic,100' rel='stylesheet' type='text/css'>
      <link href="<?=$CONTENT_URL?>/css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="<?=$CONTENT_URL?>/css/flexslider.css" type="text/css" media="screen"/>
      <link href="<?=$CONTENT_URL?>/css/sequence-looptheme.css" rel="stylesheet" media="all"/>
      <link href="<?=$CONTENT_URL?>/css/style.css" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/v4-shims.css">
      <script>
        $(function (){
            $(".datepicker").datepicker({dateFormat:'yy-mm-dd'});
        });
        </script>
        <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery-1.10.2.min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.easing.1.3.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.sequence-min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.carouFredSel-6.2.1-packed.js"></script>
      <script defer src="<?=$SITE_URL?>/js/jquery.flexslider.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/script.min.js" ></script>
      <style>
        .thumbnail img {
          max-height: 100%;
        }
      </style>
</head>
</head>
<body>
	<?php
	require 'giohang.php';
	?>
</body>
</html>