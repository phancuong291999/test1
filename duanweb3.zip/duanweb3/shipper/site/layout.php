<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="shortcut icon" href="<?=$CONTENT_URL?>/images/favicon.png">
      <title>Welcome to FlatShop</title>
      <link href="<?=$CONTENT_URL?>/css/bootstrap.css" rel="stylesheet">
      <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,700,500italic,100italic,100' rel='stylesheet' type='text/css'>
      <link href="<?=$CONTENT_URL?>/css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="<?=$CONTENT_URL?>/css/flexslider.css" type="text/css" media="screen"/>
      <link href="<?=$CONTENT_URL?>/css/sequence-looptheme.css" rel="stylesheet" media="all"/>
      <link href="<?=$CONTENT_URL?>/css/style.css" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/v4-shims.css">
      <script>
        $(function (){
            $(".datepicker").datepicker({dateFormat:'yy-mm-dd'});
        });
        </script>
        <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery-1.10.2.min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.easing.1.3.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.sequence-min.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/jquery.carouFredSel-6.2.1-packed.js"></script>
      <script defer src="<?=$SITE_URL?>/js/jquery.flexslider.js"></script>
      <script type="text/javascript" src="<?=$CONTENT_URL?>/js/script.min.js" ></script>
      <style>
        .thumbnail img {
          max-height: 100%;
        }
        .offer{
         height: 0px;
          overflow: hidden;
          padding: 0px;
          transition: 0.5s;
          opacity: 0;
        }
        .offer a{
          color: white;
        }

        .products:hover .offer {
          height: 39px;
          padding: 10px;
              top: 151px;
    right: 87px;
    opacity: 1;

        }
      </style>
</head>
    <body id="" style="background: url('<?=$CONTENT_URL?>/images/bg.jpg') center top no-repeat;
    background-size: cover;
    -webkit-background-size: cover;
    background-attachment: fixed;">
        <script>
new WOW().init();
</script>
<div class="wrapper">
        <?php require 'layout/header.php' ?> 
        <?php
                        require $HEADER;
        ?>
                    <?php
                        require $VIEW_NAME;
                    ?>
                    
                <?php require '../layout/footer.php'?>
            </div>
             
    </body>
</html>
