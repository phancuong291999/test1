<?php 
require_once "../../global.php";
require_once "../../dao/don-hang.php";

$ma_TT=$_GET["ma_TT"];
if ($trang_thai==0) {
		$update=thanh_toan_update($ma_TT,$trang_thai);
		$_SESSION['massages']="Đã xử lí đơn hàng ". $ma_TT;
		header("location:index.php");
}
else{
$_SESSION['massages']= "Đơn hàng ".$ma_TT." đã xử lí rồi!";
header("location:index.php");
}
?>