<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <!-- Latest compiled and minified CSS & JS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <script src="//code.jquery.com/jquery.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
</head>
    <body>
        <div style="width: 80%;margin: 0 auto;">
            <h3 class="alert alert-success" style="text-align: center;">QUẢN LÝ ĐƠN HÀNG BÁN</h3>
            <table class="table table-hover" style="border: 1px solid #cccc">
                <thead>
                    <tr>
                        <th>Khách Hàng Mua</th>
                        <th>Tổng Tiền</th>
                        <th>Ngày Tạo</th>
                        <th>Địa Chỉ</th>
                        <th>Ghi Chú</th>
                        <th>Chi Tiết</th>
                        <th>Trạng Thái</th>
                    </tr>
                </thead>
                <tbody>
     <?php
     require "../../global.php";
require "../../dao/don-hang.php";
                $ma_kh_ban = get_cookie("ma_kh");
                    $loai_array = don_hang_select_by_makh($ma_kh_ban);
                    foreach ($loai_array as $loai) {
                        echo "
                        <tr>
                            <td><a href=''>$loai[ma_kh]</a></td>
                            <td><a href=''>$loai[gia_dh]</a></td>
                            <td><a href=''>$loai[ngay_tao]</a></td>     
                            <td><a href=''>$loai[dia_chi]</a></td> 
                            <td><a href=''>$loai[note]</a></td> 
                             <td><a href='chitiet.php?ma_TT=$loai[ma_TT]'>Xem Chi Tiết</a></td>
                              <td><a href='xuli.php?ma_TT=$loai[ma_TT]'><button type='button' class='btn btn-default'>$loai[trang_thai]</a></button></td>  
                        </tr>
                        ";
                    }

                ?>
            </tbody></table>
            <a href='javascript:goback()'>
            <button type="button" class="btn btn-default">Quay Lại</button>
        </a>
                </div> 
                <script type="text/javascript" charset="utf-8" async defer>
                    function goback() {
    history.back(-1)
}
                </script>
    </body>
</html>