<!DOCTYPE html>
<html>
<style type="text/css">
    label {
        width: 120px;
    }
    form div {
        margin: 5px;
    }
</style>
    <body>
        <div class="container_fullwidth">
        <div class="container">
        <div class="alert alert-danger">
            <h3>Đăng ký thành viên</h3>
        </div>
        <div class="alert alert-danger">
        <?php
            if(strlen($MESSAGE)){
                echo "<h5>$MESSAGE</h5>";
            }
        ?>
        </div>
        <div class="form-nhap">
        <form action="dang-ky.php" method="post" enctype="multipart/form-data">
            <div class="form-group col-sm-4">
                <label>Tên đăng nhập</label>
                <input required class="form-control" name="ma_kh" value="<?=$ma_kh?>">
            </div>
            <div class="form-group col-sm-4">
                <label>Mật khẩu</label>
                <input  required class="form-control" name="mat_khau" type="password" value="<?=$mat_khau?>">
            </div>
            <div class="form-group col-sm-4">
                <label>Xác nhận mật khẩu</label>
                <input  required name="mat_khau2" class="form-control" type="password" value="<?=$mat_khau2?>">
            </div>
            <div class="form-group col-sm-4">
                <label>Họ và tên</label>
                <input required class="form-control" name="ho_ten" value="<?=$ho_ten?>">
            </div>
            <div class="form-group col-sm-4">
                <label>Địa chỉ email</label>
                <input required class="form-control" name="email" value="<?=$email?>">
            </div>
            <div class="form-group col-sm-4">
                <label>Hình</label>
                <input name="up_hinh" type="file">
            </div>
            <div class="form-group col-sm-4">
                <button name="btn_register">Đăng ký</button>
            </div>
            <!--Giá trị mặc định-->
            <input name="vai_tro" value="0" type="hidden">
            <input name="kich_hoat" value="0" type="hidden">
        </form>
    </div>
</div>
</div>
    </body>
</html>
