<!DOCTYPE html>
<html>
<style type="text/css">
    label {
        width: 120px;
    }
    form div {
        margin: 5px;
    }
</style>
    <body>
        <div class="container_fullwidth">
            <div class="container">
        <h3 >ĐỔI MẬT KHẨU</h3>
        <?php
            if(strlen($MESSAGE)){
                echo "<h5>$MESSAGE</h5>";
            }
        ?>
        <form action="doi-mk.php" method="post">
            <div class="form-group col-sm-7">
                <label>Tên đăng nhập</label>
                <input class="form-control" name="ma_kh">
            </div>
            <div class="form-group col-sm-7">
                <label>Mật khẩu cũ</label>
                <input class="form-control" name="mat_khau" type="password">
            </div>
           <div class="form-group col-sm-7">
                <label>Mật khẩu mới</label>
                <input class="form-control" name="mat_khau2" type="password">
            </div>
           <div class="form-group col-sm-7">
                <label>Xác nhận mật khẩu mới</label>
                <input class="form-control" name="mat_khau3" type="password">
            </div>
            <div class="form-group col-sm-7">
                <button class="btn btn-primary" name="btn_change">Đổi mật khẩu</button>
            </div>
        </form>
    </div>
</div>
    </body>
</html>
