<!DOCTYPE html>
<html>
    <body>
         <div class="container_fullwidth">
            <div class="container">
        <h3 class="alert alert-danger">CẬP NHẬT TÀI KHOẢN</h3>
        <?php
            if(strlen($MESSAGE)){
                echo "<h5 class='alert alert-danger'>$MESSAGE</h5>";
            }
        ?>
        <form action="cap-nhat-tk.php" method="post" enctype="multipart/form-data">
            <div>
                <div>
                    <img src="<?=$CONTENT_URL?>/images/users/<?=$hinh?>" style="width: 100px;height:100px;border-radius: 100%;border: 1px solid #333;display: block;margin: 0 auto">
                </div>
                <div>
                   <div class="form-group col-sm-7">
                        <label>Tên đăng nhập</label>
                        <input class="form-control" name="ma_kh" value="<?=$ma_kh?>" readonly>
                    </div>
                    <div class="form-group col-sm-7">
                        <label>Họ và tên</label>
                        <input class="form-control" name="ho_ten" value="<?=$ho_ten?>">
                    </div>
                   <div class="form-group col-sm-7">
                        <label>Địa chỉ email</label>
                        <input class="form-control" name="email" value="<?=$email?>">
                    </div>
                   <div class="form-group col-sm-7">
                        <label>Hình</label>
                        <input class="form-control" name="up_hinh" type="file">
                    </div>
                    <div class="form-group col-sm-7">
                        <button class="btn btn-primary" name="btn_update">Cập nhật</button>
                    </div>
                    <!--Giá trị mặc định-->
                    <input name="vai_tro" value="<?=$vai_tro?>" type="hidden">
                    <input name="kich_hoat" value="<?=$kich_hoat?>" type="hidden">
                    <input name="mat_khau" value="<?=$mat_khau?>" type="hidden">
                    <input name="hinh" value="<?=$hinh?>" type="hidden">
                </div>
            </div>
        </form>
    </div></div>
    </body>
</html>
