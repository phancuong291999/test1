-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 15, 2018 lúc 07:26 AM
-- Phiên bản máy phục vụ: 10.1.33-MariaDB
-- Phiên bản PHP: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `du-an-mau`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `binh_luan`
--

CREATE TABLE `binh_luan` (
  `ma_bl` int(11) NOT NULL COMMENT 'Mã bình luận',
  `noi_dung` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nội dung bình luận',
  `ma_hh` int(11) NOT NULL COMMENT 'Mã hàng hóa được bình luận',
  `ma_kh` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Mã người bình luận',
  `ngay_bl` date NOT NULL COMMENT 'Thời gian bình luận'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `binh_luan`
--

INSERT INTO `binh_luan` (`ma_bl`, `noi_dung`, `ma_hh`, `ma_kh`, `ngay_bl`) VALUES
(1, 'tôi muốn mua sp này', 1, 'KH001', '2018-09-19'),
(2, 'đá', 2, 'KH001', '2018-10-01'),
(3, '', 2, 'KH001', '2018-10-04'),
(4, '', 2, 'KH001', '2018-10-04'),
(5, '', 2, 'KH001', '2018-10-04'),
(6, '', 2, 'KH001', '2018-10-04'),
(7, '', 2, 'KH001', '2018-10-04'),
(8, '', 2, 'KH001', '2018-10-04'),
(9, '', 2, 'KH001', '2018-10-04'),
(10, '', 2, 'KH001', '2018-10-04'),
(11, '', 2, 'KH001', '2018-10-04'),
(12, '', 2, 'KH001', '2018-10-04'),
(13, '', 2, 'KH001', '2018-10-04'),
(14, 'nội dung', 2, 'KH001', '2018-10-04'),
(15, 'dsa', 2, 'kh002', '2018-10-04');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hang_hoa`
--

CREATE TABLE `hang_hoa` (
  `ma_hh` int(11) NOT NULL COMMENT ' Mã hàng hóa',
  `ten_hh` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Tên hàng hóa',
  `don_gia` float NOT NULL COMMENT 'Đơn giá',
  `giam_gia` float NOT NULL COMMENT 'Mức giảm giá',
  `hinh` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Hình ảnh',
  `ngay_nhap` date NOT NULL COMMENT 'Ngày nhập hàng',
  `mo_ta` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Mô tả hàng hóa',
  `dac_biet` bit(1) NOT NULL COMMENT 'Trạng thái đặc biệt',
  `so_luot_xem` int(11) NOT NULL DEFAULT '0' COMMENT 'Số lượt xem',
  `ma_loai` int(11) NOT NULL COMMENT 'Mã loại'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hang_hoa`
--

INSERT INTO `hang_hoa` (`ma_hh`, `ten_hh`, `don_gia`, `giam_gia`, `hinh`, `ngay_nhap`, `mo_ta`, `dac_biet`, `so_luot_xem`, `ma_loai`) VALUES
(1, ' Vợt cầu lông Yonex Astrox 99 - Xách tay ', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Vợt cầu lông Yonex Astrox 99 được xem là sản phẩm đỉnh nhất năm của hãng sản xuất của Nhật Bản. Trước khi tung ra sản phẩm này, các dòng khác của Astrox đã làm mưa làm gió với làng cầu lông thế giới như Astrox 66, 77 và cặp đôi 88S - 88D. Vì lẽ đó, không quá ngạc nhiên khi hầu như những ai yêu thích môn cầu lông đều đổ dồn mọi con mắt trông chờ vào dòng vợt siêu hot Astrox 99 này.', b'1', 40, 1),
(2, 'Vợt cầu lông Yonex Duora 99', 2179000, 79000, 'giaythethao4.jpg', '2018-09-16', 'Duora là dòng vợt cực kỳ thành công của Yonex, không chỉ dễ dàng kiểm soát cầu mà với thiết kế “2 mặt” 1 mặt để cho tay thuận đánh những quả cầu uy lực, 1 mặt thiết kế cho cú trái tay nhanh , đây thật sự là cây vợt cầu lông nâng tầm cuộc chơi lên tầm cao mới khi dễ dàng đánh những cú thuận tay mạnh mẽ, những cú trái tay nhanh và thoát cầu, kèm khả năng kiểm soát tối ưu trong tạt, đập, bỏ cài cầu.', b'1', 63, 1),
(3, ' Vợt cầu lông Yonex Astrox 99 - Xách tay ', 3599000, 99000, 'giaythethao3.jpg', '2018-09-16', 'Vợt cầu lông Yonex Astrox 99 được xem là sản phẩm đỉnh nhất năm của hãng sản xuất của Nhật Bản. Trước khi tung ra sản phẩm này, các dòng khác của Astrox đã làm mưa làm gió với làng cầu lông thế giới như Astrox 66, 77 và cặp đôi 88S - 88D. Vì lẽ đó, không quá ngạc nhiên khi hầu như những ai yêu thích môn cầu lông đều đổ dồn mọi con mắt trông chờ vào dòng vợt siêu hot Astrox 99 này.', b'1', 21, 1),
(4, ' Vợt cầu lông Yonex Astrox 99 - Xách tay ', 3599000, 99000, 'giaythethao1.jpg', '2018-09-16', 'Vợt cầu lông Yonex Astrox 99 được xem là sản phẩm đỉnh nhất năm của hãng sản xuất của Nhật Bản. Trước khi tung ra sản phẩm này, các dòng khác của Astrox đã làm mưa làm gió với làng cầu lông thế giới như Astrox 66, 77 và cặp đôi 88S - 88D. Vì lẽ đó, không quá ngạc nhiên khi hầu như những ai yêu thích môn cầu lông đều đổ dồn mọi con mắt trông chờ vào dòng vợt siêu hot Astrox 99 này.', b'1', 1, 3),
(5, ' Vợt cầu lông Yonex Astrox 99 - Xách tay ', 5454, 9000, 'giaythethao2.jpg', '2018-09-16', 'Vợt cầu lông Yonex Astrox 99 được xem là sản phẩm đỉnh nhất năm của hãng sản xuất của Nhật Bản. Trước khi tung ra sản phẩm này, các dòng khác của Astrox đã làm mưa làm gió với làng cầu lông thế giới như Astrox 66, 77 và cặp đôi 88S - 88D. Vì lẽ đó, không quá ngạc nhiên khi hầu như những ai yêu thích môn cầu lông đều đổ dồn mọi con mắt trông chờ vào dòng vợt siêu hot Astrox 99 này.', b'1', 76, 2),
(6, ' Vợt cầu lông Yonex Astrox 99 - Xách tay ', 3599000, 99000, 'giaythethao3.jpg', '2018-09-16', 'Vợt cầu lông Yonex Astrox 99 được xem là sản phẩm đỉnh nhất năm của hãng sản xuất của Nhật Bản. Trước khi tung ra sản phẩm này, các dòng khác của Astrox đã làm mưa làm gió với làng cầu lông thế giới như Astrox 66, 77 và cặp đôi 88S - 88D. Vì lẽ đó, không quá ngạc nhiên khi hầu như những ai yêu thích môn cầu lông đều đổ dồn mọi con mắt trông chờ vào dòng vợt siêu hot Astrox 99 này.', b'1', 0, 4),
(7, ' Vợt cầu lông Yonex Astrox 99 - Xách tay ', 3599000, 99000, 'giay4.jpg', '2018-09-16', 'Vợt cầu lông Yonex Astrox 99 được xem là sản phẩm đỉnh nhất năm của hãng sản xuất của Nhật Bản. Trước khi tung ra sản phẩm này, các dòng khác của Astrox đã làm mưa làm gió với làng cầu lông thế giới như Astrox 66, 77 và cặp đôi 88S - 88D. Vì lẽ đó, không quá ngạc nhiên khi hầu như những ai yêu thích môn cầu lông đều đổ dồn mọi con mắt trông chờ vào dòng vợt siêu hot Astrox 99 này.', b'1', 1, 5),
(9, ' Vợt cầu lông Yonex Astrox 99 - Xách tay ', 3599000, 99000, 'giaythethao4.jpg', '2018-09-16', 'Vợt cầu lông Yonex Astrox 99 được xem là sản phẩm đỉnh nhất năm của hãng sản xuất của Nhật Bản. Trước khi tung ra sản phẩm này, các dòng khác của Astrox đã làm mưa làm gió với làng cầu lông thế giới như Astrox 66, 77 và cặp đôi 88S - 88D. Vì lẽ đó, không quá ngạc nhiên khi hầu như những ai yêu thích môn cầu lông đều đổ dồn mọi con mắt trông chờ vào dòng vợt siêu hot Astrox 99 này.', b'1', 0, 6),
(10, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 2),
(11, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 2, 2),
(12, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 2),
(13, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 1, 3),
(14, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 1, 1),
(15, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 3),
(16, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 3),
(17, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 4),
(18, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 4),
(19, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 4),
(20, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 1, 5),
(21, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 1, 5),
(22, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 1, 5),
(23, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 1, 6),
(24, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 6),
(25, 'Giày', 3599000, 99000, 'giay3.jpg', '2018-09-16', 'Giày Chất Lượng Cao', b'1', 0, 6);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khach_hang`
--

CREATE TABLE `khach_hang` (
  `ma_kh` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Mã đăng nhập',
  `mat_khau` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Mật khẩu',
  `ho_ten` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Họ và tên',
  `kich_hoat` bit(1) NOT NULL COMMENT 'Trạng thái kích hoạt',
  `hinh` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Tên hình ảnh',
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Địa chỉ email',
  `vai_tro` bit(1) NOT NULL COMMENT 'Vai trò, true là nhân viên'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `khach_hang`
--

INSERT INTO `khach_hang` (`ma_kh`, `mat_khau`, `ho_ten`, `kich_hoat`, `hinh`, `email`, `vai_tro`) VALUES
('KH001', 'kh001', 'Lê Công Thưởng', b'1', 'Developer-Sw_1433072485.jpg', 'dattdpd02368@fpt.edu.vn', b'1'),
('kh002', 'lecongthuong', 'Lê Công Thưởng', b'1', 'Developer-Sw_1433072485.jpg', 'thuonglcpd02347@fpt.edu.vn', b'0');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loai`
--

CREATE TABLE `loai` (
  `ma_loai` int(11) NOT NULL COMMENT 'Mã loại hàng',
  `ten_loai` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Tên loại hàng'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `loai`
--

INSERT INTO `loai` (`ma_loai`, `ten_loai`) VALUES
(1, 'Alexander McQueen'),
(2, 'Giày cầu lông'),
(3, 'Áo cầu lông'),
(4, 'Balo cầu lông'),
(5, 'Túi đụng vợt cầu lông'),
(6, 'Phụ kiện cầu lông');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `binh_luan`
--
ALTER TABLE `binh_luan`
  ADD PRIMARY KEY (`ma_bl`),
  ADD KEY `ma_kh` (`ma_kh`),
  ADD KEY `ma_kh_2` (`ma_kh`),
  ADD KEY `ma_hh` (`ma_hh`);

--
-- Chỉ mục cho bảng `hang_hoa`
--
ALTER TABLE `hang_hoa`
  ADD PRIMARY KEY (`ma_hh`),
  ADD KEY `ma_loai` (`ma_loai`);

--
-- Chỉ mục cho bảng `khach_hang`
--
ALTER TABLE `khach_hang`
  ADD PRIMARY KEY (`ma_kh`);

--
-- Chỉ mục cho bảng `loai`
--
ALTER TABLE `loai`
  ADD PRIMARY KEY (`ma_loai`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `binh_luan`
--
ALTER TABLE `binh_luan`
  MODIFY `ma_bl` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Mã bình luận', AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `hang_hoa`
--
ALTER TABLE `hang_hoa`
  MODIFY `ma_hh` int(11) NOT NULL AUTO_INCREMENT COMMENT ' Mã hàng hóa', AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT cho bảng `loai`
--
ALTER TABLE `loai`
  MODIFY `ma_loai` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Mã loại hàng', AUTO_INCREMENT=7;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `binh_luan`
--
ALTER TABLE `binh_luan`
  ADD CONSTRAINT `binh_luan_ibfk_1` FOREIGN KEY (`ma_kh`) REFERENCES `khach_hang` (`ma_kh`),
  ADD CONSTRAINT `binh_luan_ibfk_2` FOREIGN KEY (`ma_hh`) REFERENCES `hang_hoa` (`ma_hh`);

--
-- Các ràng buộc cho bảng `hang_hoa`
--
ALTER TABLE `hang_hoa`
  ADD CONSTRAINT `hang_hoa_ibfk_1` FOREIGN KEY (`ma_loai`) REFERENCES `loai` (`ma_loai`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
