<!DOCTYPE html>
<html>
    <body>
        <h3>QUẢN LÝ LOẠI HÀNG</h3>
        <?php
            if(strlen($MESSAGE)){
                echo "<h5>$MESSAGE</h5>";
            }
        ?>
        <form action="index.php" method="POST" role="form">
            <div class="form-group">
                <label for="">Mã Loại</label>
                <input type="text" class="form-control" name="ma_loai" value="auto number" readonly>
            </div>
            <div class="form-group">
                <label>Tên loại</label>
                <input type="text" class="form-control" id=""  name="ten_loai">
            </div>
        <button name="btn_insert" class="btn btn-primary">Thêm mới</button>
                <button type="reset" class="btn btn-primary">Nhập lại</button>
                <a href="index.php?btn_list">Danh sách</a>
        </form>
    </body>
</html>
