<!DOCTYPE html>
<html>
    <body>
         <div class=" alert alert-info">
            <h3>Quản lý khách hàng</h3>
        </div>
        <?php
            if(strlen($MESSAGE)){
                echo "<h5>$MESSAGE</h5>";
            }
        ?>
        <form action="index.php" method="post" enctype="multipart/form-data">
            <div>
                <div class="col-md-6">
                    <label>MÃ KHÁCH HÀNG</label>
                    <input name="ma_kh" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>HỌ VÀ TÊN</label>
                    <input name="ho_ten" class="form-control">
                </div>
            </div>
            <div>
                <div class="col-md-6">
                    <label>MẬT KHẨU</label>
                    <input name="mat_khau" type="password" class="form-control">
                </div class="col-md-6">
                <div class="col-md-6">
                    <label>XÁC NHẬN MẬT KHẨU</label>
                    <input name="mat_khau2" type="password" class="form-control">
                </div>
            </div>
            <div>
                <div class="col-md-6">
                    <label>ĐỊA CHỈ EMAIL</label>
                    <input name="email" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>HÌNH ẢNH</label>
                    <input name="hinh" type="file" class="form-control">
                </div>
            </div>
            <div>
                <div class="col-md-6">
                    <label>KÍCH HOẠT?</label>
                    <div class="form-control">
                        <label><input name="kich_hoat" value="0" type="radio" >Chưa kích hoạt</label>
                        <label><input name="kich_hoat" value="1" type="radio" checked>Kích hoạt</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <label>VAI TRÒ</label>
                    <div class="form-control">
                        <label><input name="vai_tro" value="0" type="radio">Khách hàng</label>
                        <label><input name="vai_tro" value="1" type="radio" checked>Nhân viên</label>
                    </div>
                </div>
            </div>
            <div>
                <div>
                    <button name="btn_insert" class="btn btn-primary">Thêm mới</button>
                    <button type="reset" class="btn btn-primary">Nhập lại</button>
                    <button><a href="index.php?btn_list" class="btn btn-primary">Danh sách</a></button>
                </div>
            </div>
        </form>
    </body>
</html>