<?php 
require_once "../../global.php";

$VIEW_NAME = "trang-chinh/home.php";
require "../layout.php";