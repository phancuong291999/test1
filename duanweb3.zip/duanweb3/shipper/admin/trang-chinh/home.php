<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1 class="text-center">CÔNG CỤ QUẢN TRỊ WEBSITE</h1>
    </body>
</html>
