<?php
    header("location: site/trang-chinh");   
 ?>